# Research Journal

- [Design Document](../design/design_doc.md)

## [Date: YYYY-MM-DD]

- ...
