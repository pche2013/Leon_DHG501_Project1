# Project Design Document

## Project Title

- ...

## Project Files

- [Research Journal](../journal/research_journal.md)

## Background and Context (the W's)

- ...

## Research Puzzles

- ...

## Methodology

- ...

## Data and Sources

- ...

## Expected Outputs

- ...

## Working hypotheses

- ...

## Challenges and Risks

- ...

## Action Items

- [ ] ...
- [ ] ...
- [ ] ...
