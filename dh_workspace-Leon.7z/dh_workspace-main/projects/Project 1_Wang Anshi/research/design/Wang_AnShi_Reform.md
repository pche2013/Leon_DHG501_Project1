# Working Title: Wang AnShi Reform
## Assignment 1: Design Document
### Blueprint:
The study mainly focus on Wang Anshi Reform, the idea of develop economy by state intervention and increase the income of the state increase the burden of civilians could be a idea even every advance today.
### Research Questions
#### What：
What is the core focus of the research? 
Is it the specific measures of Wang Anshi's reforms (such as the Green Sprouts Law, the Hydraulic Resources Law, the Equitable Transport Law, the Market Exchange Law), the underlying philosophy ("managing state finance to enrich the nation," "curbing land annexation," "strengthening the military"), or the resistance encountered during implementation and the ultimate success or failure?
Focus: This study will primarily analyze two core dimensions of the reforms: "state-led macroeconomic control" and "grassroots social governance and livelihood security."

 ####  When: 
 Historical Period: The Xining and Yuanfeng eras of the Northern Song Dynasty (approximately 1069 to 1085, and their subsequent impact).

Contemporary Reference Period: The period of challenges and reforms in China since the start of reform and opening-up, particularly in the 21st century, in areas like economic development, transformation of government functions, and rural revitalization.

#### Where:
Historical Space: The core territories of the Northern Song Dynasty.
Contemporary Space: This study primarily focuses on contemporary China, though some insights (e.g., regarding the relationship between government and market) can be extended to a broader global context.

#### Who:
Historical Actors: The reform faction led by Wang Anshi (e.g., Lü Huiqing, Zeng Bu), the conservative faction opposing the reforms (e.g., Sima Guang, Wen Yanbo), Emperor Shenzong (the ultimate decision-maker), and the scholar-officials, landowners, peasants, and merchants directly affected by the reforms.
Contemporary Stakeholders: Policy makers, economists, social administrators, and various market entities (SOEs, private enterprises, individuals, farmers, etc.) affected by modern policies.

#### Why (Core Research Value):

Historical Dimension: Why did a reform intended to enrich and strengthen the nation, while technically advanced in some aspects, provoke intense controversy and ultimately fail during implementation? What were the underlying reasons? (e.g., resistance from the bureaucratic system, distortion during policy implementation, neglect of human nature and interest groups, excessive haste).

Contemporary Dimension: What profound historical lessons do the experiences and failures of Wang Anshi's Reforms offer to contemporary China and other nations regarding handling the "relationship between government and the market," "connecting top-level design with grassroots practice," "resolving resistance and building consensus during reform processes," and the "application and risks of technological innovation (e.g., digitalization) in policy implementation"?

### Actionable Hypothesis


The fundamental predicament of Wang Anshi's Reforms stemmed not from flawed goals of 'enriching the people and strengthening the state,' but from the inherent difficulties a highly centralized administrative system faced in implementing precise yet radical macroeconomic controls—namely, overcoming principal-agent problems, information asymmetry, and the neglect of human nature and local interests. In the contemporary era, despite vastly improved technological conditions (e.g., big data, the internet), if institutional design fails to effectively avoid these historical traps, any large-scale reform aimed at similar goals may still risk its execution deviating from its original intent.

The operability of this hypothesis is evident in that it is:

Verifiable: Can be tested by analyzing historical sources (e.g., History of Song, Continued Biannian General Mirror to Aid in Governance, and Song dynasty notebooks) to demonstrate the "policy distortion" that occurred during implementation (e.g., the Green Sprouts Law becoming a forced loan).

Comparable: Allows for comparative analysis between the historical case and certain policy practices in contemporary China (e.g., targeted poverty alleviation, financial support in rural revitalization, government guidance and regulation of emerging industries) to examine where contemporary institutions have innovated mechanisms (e.g., third-party evaluation, digital government platforms, village self-governance) to avoid historical pitfalls, and where similar risks still require vigilance.

Conclusive: Enables the extraction of universal methodological principles for reform based on comparative analysis, providing inspiration for contemporary governance.

Technology Choices and Justification
This refers both to research tools and contemporary technologies that may be used as analogies or arguments within the thesis.

### Technology Choice	Justification
1. Digital Humanities Tools
- Reference Management Software (e.g., Zotero, EndNote)
- Text Analysis Tools (e.g., Voyant Tools)	Justification:
• Improves Research Efficiency & Standardization: Tools like Zotero efficiently manage large quantities of digital ancient texts, modern academic books, and journal articles, automatically generating bibliographies and ensuring academic rigor.
• Uncovers Deeper Insights: Using text analysis tools on core historical sources like the History of Song for frequency analysis, co-occurrence network analysis can objectively reveal high-frequency words (e.g., "people," "wealth," "clerks," "malpractice") and core conceptual relationships, providing data-driven support for arguments beyond traditional subjective interpretation.
2. Data Analysis & Visualization Tools
- Spreadsheets (e.g., Microsoft Excel, Google Sheets)
- Visualization Software (e.g., Tableau Public, RawGraphs)	Justification:
• Quantifies Historical Impact: Allows for the organization of data (albeit incomplete) on Northern Song fiscal revenue/expenditure, population, cultivated land area before/after the reforms to create charts that visually demonstrate the short-term economic effects.
• Presents Arguments Clearly: Incorporating charts and graphs in the thesis allows for clearer comparison between historical and contemporary cases, making the argument more persuasive and modern. For example, creating a "Policy Implementation Deviation Model" diagram to compare ancient and modern scenarios.
3. Contemporary Technologies as Discussion Subjects
- Big Data & Artificial Intelligence
- Digital Government Platforms	Justification:
• Bridges the Historical-Contemporary Dialogue: This is central to the "contemporary inspiration" of the thesis. It allows for arguments such as:
- Analogy: The Green Sprouts Law Dilemma vs. Targeted Poverty Alleviation Breakthrough: Wang Anshi's inability to accurately identify farmers' true needs (information asymmetry) led to policy distortion. Contemporary big data and precise targeting technologies enable the "drip irrigation" of poverty alleviation resources, representing a technological solution to this historical problem.
- Analogy: The Market Exchange Law vs. Government Data Openness: Wang Anshi's Market Exchange Commission directly intervened in markets to stabilize prices, easily leading to rent-seeking. Contemporary open government data platforms provide transparent, macro-level market information to guide independent decision-making by market entities, representing a superior "service-oriented government" intervention model.
• Makes Historical Research Forward-Looking: Discussing these technologies not only interprets history but also explores how to use modern tools to optimize governance, grounding the "inspiration" part of the thesis in practical reality.

## Assignment 2: Research Journal

13/10/2025  
Finishing the lecture, learning markdown, Zotero 

18/10/2025  
Watching a vedio on bilibil.com about Markdown

19/10/2025  
Receive the notice about submitting assignment on moodle.
think about the topic I want to work on
Search for 10 articles

## Assignment 3: Zotero Management
Li, Y. (n.d.). The Economic Implications of Wang Anshi’s Reform.
Yang, X. (2012). Ritual Propriety and Political Intrigue in the Xuande Gate Incident. T’oung Pao, 98(1), 145–177. https://doi.org/10.1163/156853212X629910
Zhao, X., & Drechsler, W. (2018). Wang Anshi’s economic reforms: proto-Keynesian economic policy in Song Dynasty China. Cambridge Journal of Economics, 42(5), 1239–1254. https://doi.org/10.1093/cje/bex087
在线阅读-严复“究心赵宋一代历史”观念探讨——兼论严复对王安石变法之态度. (n.d.). Retrieved October 19, 2025, from https://chn.oversea.cnki.net/kreader2/flowpdf?invoice=p9Ol02ZbZu0zbiRVkU05h90hIiVLXBl6R9mo%252FyKba%252BsZK1ADm8FC1NRgdAyBCedVWTH5res7dPUXmZGsgwfsn8JUb2L4xRnWLwfBzcYQrWrrrSHgVRUoTweMhq7Hz284ALf8QmgrluNicS531YPFRWlYjeYA6JqGvJUMuFrGB48%253D&platform=OVERSEA&product=CJFD&filename=HSXX202406003&tablename=cjfdlast2025&type=JOURNAL&scope=trial&cflag=overlay&dflag=&pages=&language=chs&trial=&nonce=1660EE75141444889C02BEFC8C74148C
在线阅读-智谋制胜——重温商鞅变法准备阶段的谈判(英文). (n.d.). Retrieved October 19, 2025, from https://chn.oversea.cnki.net/kreader2/flowpdf?invoice=FiWHTt0lcDsL9k5KmCAAXx3DF5T0gT1lKdLd2nJn7gGxtZA8PBABYJWSzcExqTE%252BSkBfOp80TVCfRYJRRBn0ZsKLgu4N0I1PE9VQ6bVPYsGI5S5UKRdDdXGFiwkevB9hTFTXKUnywa%252Br%252BkTloBCS62FH09fpfAIK8KVMmbdcaOY%253D&platform=OVERSEA&product=CJFD&filename=WQZG201218217&tablename=cjfd2012&type=JOURNAL&scope=trial&cflag=overlay&dflag=&pages=&language=chs&trial=&nonce=06C226743C2B40A9BF19B057EE42EB5F
在线阅读-王安石变法失败原因初探. (n.d.). Retrieved October 19, 2025, from https://chn.oversea.cnki.net/kreader2/flowpdf?invoice=Kk5rWRFH%252FJPjK75wL91mQrnxPUl4X6RdVJjlsEsCi%252B9McD4pVZQ5rIRW1WT3312M8u26KNnfEluH%252B8yLCpGfDDBMHHgNgqzaqke8AeRG%252FErMzOdZedqdJdfldmuH2U2buvoDQw8gmfzqf0vzAVLqiTOw5Xpi%252Bu1cgalowWbIG98%253D&platform=OVERSEA&product=CJFD&filename=JMSA201817248&tablename=cjfdlast2018&type=JOURNAL&scope=trial&cflag=overlay&dflag=&pages=&language=chs&trial=&nonce=BA0B9272C49B468099DC7E5D59FABEFC
王安石变法. (n.d.). Retrieved October 19, 2025, from https://img.chinamaxx.net/n/abroad/hwbook/chinamaxx/11326041/e0959fada6364b90aeb5021e3f379f1e/06db4ece10835693cd49ddfa9c909d10.shtml?tp=jpabroad&fenlei=110304040402&spage=1&username=175.159.253.95
群体断层激活及负面效应涌现：熙宁变法缘何从志同道合走向四分五裂? (n.d.). Retrieved October 19, 2025, from https://journal.psych.ac.cn/xlxb/CN/10.3724/SP.J.1041.2023.00336