# Project Design Document

## Project Title

- Wang Anshi's Reform and Interpersonal Network

## Project Files

- [Research Journal](../journal/research_journal.md)

## Background and Context (the W's)

- Background:
The study mainly focus on Wang Anshi Reform, managing state finance by state-led macroeconomic control to enrich the nation

- What: 
Wang Anshi's reforms: 
1. Green Sprouts Law
2. Hydraulic Resources Law
3. Equitable Transport Law
4. Market Exchange Law
  
managing state finance to enrich the nation 
curbing land annexation
strengthening the military
the resistance encountered during implementation 

- When:
The Xining and Yuanfeng eras of the Northern Song Dynasty (approximately 1069 to 1085, and their subsequent impact).

- Where：The core territories of the Northern Song Dynasty.

- Who:
1. Core Supporters (The New Party)

This group was the core team for Wang Anshi's reforms, though the personal integrity and motives of many were later heavily criticized.

1) Lü Huiqing (1032-1111)
Relationship: His most important deputy and ultimate political enemy.

2) Zhang Dun (1035-1105)
Relationship: A staunch reformist ally.

3) Zeng Bu (1036-1107)
Relationship: An important reformist colleague, later a defector.

4) Wang Pang (1044-1076)
Relationship: Wang Anshi's son.

2. Major Opponents (The Old Party)
This was a stellar group of individuals, mostly Wang's former friends, who parted ways with him over his reforms. Their opposition was primarily based on the view that the reforms were too radical, exploited the people for state profit, and violated Confucian principles of benevolent governance.

1) Sima Guang (1019-1086)
Relationship: His greatest political rival, yet once a mutually respectful friend.

2) Su Shi (1037-1101) and Su Zhe (1039-1112)
Relationship: Turned from potential allies into opponents.

3) Han Qi (1008-1075)
Relationship: Senior statesman, early patron, later an opponent.

4) Ouyang Xiu (1007-1072)
Relationship: Literary mentor and early patron.

3. Mentors, Friends, and Neutrals
1) Zeng Gong (1019-1083)
Relationship: A lifelong close friend.

2) Zhou Dunyi (1017-1073)
Relationship: Intellectual influence.

4. The Supreme Authority: The Emperor
1) Emperor Shenzong of Song (1048-1085)
Relationship: The reforms' supreme supporter and protector.

Interpersonal Network Summary Chart**

| Person | Relationship with Wang Anshi | Stance on Reforms | Key Point |
| :--- | :--- | :--- | :--- |
| **Emperor Shenzong** | Ruler & Reform Ally | Supreme Supporter | The relationship determined the fate of the reforms. |
| **Lü Huiqing** | Aide → Political Enemy | Supporter (New Party) | The most talented but most destructive ally. |
| **Zhang Dun** | Loyal Ally | Supporter (New Party) | Staunch second-generation reform core. |
| **Wang Pang** | Son & Strategist | Supporter (New Party) | Family inner circle, source of radical strategies. |
| **Sima Guang** | Friend → Political Enemy | Opponent (Old Party Leader) | A clash of principles, fundamental ideological opposition. |
| **Su Shi/Su Zhe** | Colleagues → Political Enemies | Opponents (Old Party) | From literary friends to political rivals, reconciled later in life. |
| **Han Qi** | Senior Mentor → Opponent | Opponent (Old Party) | The opposition of a senior statesman carried immense weight. |
| **Ouyang Xiu** | Literary Mentor | Mild Opposition | Admired his talent, disagreed with his methods. |
| **Zeng Gong** | Lifelong Friend | Largely Neutral | A model of personal friendship transcending political views. |

- Why (Core Research Value):

Historical Dimension: Why did a reform intended to enrich and strengthen the nation, while technically advanced in some aspects, provoke intense controversy and ultimately fail during implementation? What were the underlying reasons? (e.g., resistance from the bureaucratic system, distortion during policy implementation, neglect of human nature and interest groups, excessive haste).

Contemporary Dimension: What profound historical lessons do the experiences and failures of Wang Anshi's Reforms offer to contemporary China and other nations regarding handling the "relationship between government and the market," "connecting top-level design with grassroots practice," "resolving resistance and building consensus during reform processes," and the "application and risks of technological innovation (e.g., digitalization) in policy implementation"?

## Research Puzzles

- ...

## Methodology

- Network Analysis, Mapping

## Data and Sources

- CBDB
Li, Y. (n.d.). The Economic Implications of Wang Anshi’s Reform.
Yang, X. (2012). Ritual Propriety and Political Intrigue in the Xuande Gate Incident. T’oung Pao, 98(1), 145–177. https://doi.org/10.1163/156853212X629910
Zhao, X., & Drechsler, W. (2018). Wang Anshi’s economic reforms: proto-Keynesian economic policy in Song Dynasty China. Cambridge Journal of Economics, 42(5), 1239–1254. https://doi.org/10.1093/cje/bex087
在线阅读-严复“究心赵宋一代历史”观念探讨——兼论严复对王安石变法之态度. (n.d.). Retrieved October 19, 2025, from https://chn.oversea.cnki.net/kreader2/flowpdf?invoice=p9Ol02ZbZu0zbiRVkU05h90hIiVLXBl6R9mo%252FyKba%252BsZK1ADm8FC1NRgdAyBCedVWTH5res7dPUXmZGsgwfsn8JUb2L4xRnWLwfBzcYQrWrrrSHgVRUoTweMhq7Hz284ALf8QmgrluNicS531YPFRWlYjeYA6JqGvJUMuFrGB48%253D&platform=OVERSEA&product=CJFD&filename=HSXX202406003&tablename=cjfdlast2025&type=JOURNAL&scope=trial&cflag=overlay&dflag=&pages=&language=chs&trial=&nonce=1660EE75141444889C02BEFC8C74148C
在线阅读-智谋制胜——重温商鞅变法准备阶段的谈判(英文). (n.d.). Retrieved October 19, 2025, from https://chn.oversea.cnki.net/kreader2/flowpdf?invoice=FiWHTt0lcDsL9k5KmCAAXx3DF5T0gT1lKdLd2nJn7gGxtZA8PBABYJWSzcExqTE%252BSkBfOp80TVCfRYJRRBn0ZsKLgu4N0I1PE9VQ6bVPYsGI5S5UKRdDdXGFiwkevB9hTFTXKUnywa%252Br%252BkTloBCS62FH09fpfAIK8KVMmbdcaOY%253D&platform=OVERSEA&product=CJFD&filename=WQZG201218217&tablename=cjfd2012&type=JOURNAL&scope=trial&cflag=overlay&dflag=&pages=&language=chs&trial=&nonce=06C226743C2B40A9BF19B057EE42EB5F
在线阅读-王安石变法失败原因初探. (n.d.). Retrieved October 19, 2025, from https://chn.oversea.cnki.net/kreader2/flowpdf?invoice=Kk5rWRFH%252FJPjK75wL91mQrnxPUl4X6RdVJjlsEsCi%252B9McD4pVZQ5rIRW1WT3312M8u26KNnfEluH%252B8yLCpGfDDBMHHgNgqzaqke8AeRG%252FErMzOdZedqdJdfldmuH2U2buvoDQw8gmfzqf0vzAVLqiTOw5Xpi%252Bu1cgalowWbIG98%253D&platform=OVERSEA&product=CJFD&filename=JMSA201817248&tablename=cjfdlast2018&type=JOURNAL&scope=trial&cflag=overlay&dflag=&pages=&language=chs&trial=&nonce=BA0B9272C49B468099DC7E5D59FABEFC
王安石变法. (n.d.). Retrieved October 19, 2025, from https://img.chinamaxx.net/n/abroad/hwbook/chinamaxx/11326041/e0959fada6364b90aeb5021e3f379f1e/06db4ece10835693cd49ddfa9c909d10.shtml?tp=jpabroad&fenlei=110304040402&spage=1&username=175.159.253.95
群体断层激活及负面效应涌现：熙宁变法缘何从志同道合走向四分五裂? (n.d.). Retrieved October 19, 2025, from https://journal.psych.ac.cn/xlxb/CN/10.3724/SP.J.1041.2023.00336

## Expected Outputs

- ...

## Working hypotheses

- ...

## Challenges and Risks

- ...

## Action Items

- [ ] ...
- [ ] ...
- [ ] ...
