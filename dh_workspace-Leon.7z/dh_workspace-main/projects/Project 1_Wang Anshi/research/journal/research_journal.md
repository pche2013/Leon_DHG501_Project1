# Research Journal

- [Design Document](../design/design_doc.md)

## [Date: 2025-10-13]

- Finishing the lecture, learning markdown, Zotero 

## [Date: 2025-10-18]

- Watch a vedio on bilibil.com about Markdown

## [Date: 2025-10-19]

- Receive the notice about submitting assignment on moodle.
- Think about the topic I want to work on
- Search for 10 articles

## [Date: 2025-10-26]

- Attempt to Sign up for CBDB database, but not accessable from my network set up.
- Use Deepseek to Search for Wang Anshi's Network.

## [Date: 2025-10-27]

- Get access to CBDB database, learn about CBDB SQlite

## [Date: 2025-11-01]

-Downloaded SQlite Version of CBDB database, attempt to open with google colab but failed, opened with DB Browser , but still need to figure out how to extract selected data. 

## [Date: 2025-11-02]

- Work on Annotation and Primary Sources and Secondary Sources

