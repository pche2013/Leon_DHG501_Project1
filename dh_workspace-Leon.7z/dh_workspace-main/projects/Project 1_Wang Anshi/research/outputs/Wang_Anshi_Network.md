

---

# **Wang Anshi's Interpersonal Network**

Wang Anshi's interpersonal network was extremely complex and was a crucial part of his life's work and its tragedy. This network, centered around his **political ideology (the New Policies)**, formed the "New Party" that supported him and the "Old Party" (or "Conservatives") that opposed him, intertwined with relationships of mentors, friends, students, and family.

Below is a chart of his main interpersonal connections:

### **I. Core Supporters (The New Party)**

This group was the core team for Wang Anshi's reforms, though the personal integrity and motives of many were later heavily criticized.

1.  **Lü Huiqing (1032-1111)**
    *   **Relationship**: **His most important deputy and ultimate political enemy.**
    *   **Details**: Initially regarded by Wang Anshi as his most capable lieutenant, dubbed the "Guardian Deva." He was brilliant but intensely ambitious for power. During Wang's first period out of office, Lü, to consolidate his own position, not only sidelined other New Party members but even attempted to frame Wang Anshi, causing an irreparable rift between them. After Wang returned as chancellor, their relationship was broken beyond repair.

2.  **Zhang Dun (1035-1105)**
    *   **Relationship**: A staunch reformist ally.
    *   **Details**: Known for his resolute and forceful character, he was a firm supporter of Wang Anshi's reforms. After Emperor Zhezong took personal power, he reinstated the New Policies with even more vigor than Wang. Although he later clashed with Lü Huiqing and others, he always maintained respect for Wang Anshi.

3.  **Zeng Bu (1036-1107)**
    *   **Relationship**: An important reformist colleague, later a defector.
    *   **Details**: He was a key supporter of Wang Anshi and initially oversaw the implementation of the Market Exchange Law. However, he fell out with Wang due to power struggles with Lü Huiqing and his criticism of the law's specific execution, eventually defecting to the opposition camp.

4.  **Wang Pang (1044-1076)**
    *   **Relationship**: **Wang Anshi's son.**
    *   **Details**: Highly talented, intellectually sharp, and politically radical, he was his father's confidant and private strategist. He participated in planning many of the New Policies and actively helped his father combat political opponents. His early death was a devastating blow to Wang Anshi.

### **II. Major Opponents (The Old Party)**

This was a stellar group of individuals, mostly Wang's former friends, who parted ways with him over his reforms. Their opposition was primarily based on the view that the reforms were too radical, exploited the people for state profit, and violated Confucian principles of benevolent governance.

1.  **Sima Guang (1019-1086)**
    *   **Relationship**: **His greatest political rival, yet once a mutually respectful friend.**
    *   **Details**: The two had served together under Bao Zheng in their early careers and admired each other's talent and character. However, with the start of the reforms, Sima Guang became the leader of the opposition. He engaged in fierce debates with Wang through letters and, after Wang's fall from power, repealed almost all of the New Policies. Their conflict was a struggle between principled men, but their positions were irreconcilable.

2.  **Su Shi (1037-1101) and Su Zhe (1039-1112)**
    *   **Relationship**: Turned from potential allies into opponents.
    *   **Details**: The Su brothers initially also advocated for reform but believed Wang's methods were too radical and impatient. Su Shi used poetry to satirize the new policies, leading to the "Crow Terrace Poetry Case"; Su Zhe directly submitted memorials criticizing the laws. Both were consequently exiled. In their later years, Wang Anshi and Su Shi reconciled during a meeting in Jinling, a celebrated anecdote in literary history.

3.  **Han Qi (1008-1075)**
    *   **Relationship**: Senior statesman, early patron, later an opponent.
    *   **Details**: Han Qi had once been a senior figure who recognized Wang's talent. However, upon witnessing the negative effects of the "Green Sprouts Law" in practice, he, as a leading elder statesman, spearheaded the opposition, creating significant pressure for Wang Anshi.

4.  **Ouyang Xiu (1007-1072)**
    *   **Relationship**: Literary mentor and early patron.
    *   **Details**: Ouyang Xiu greatly admired Wang Anshi's literary talent, wrote poems for him, and recommended him for court positions. However, Ouyang was more conservative in his approach to reform and expressed reservations about laws like the Green Sprouts Law.

### **III. Mentors, Friends, and Neutrals**

1.  **Zeng Gong (1019-1083)**
    *   **Relationship**: **A lifelong close friend.**
    *   **Details**: Fellow natives of Jiangxi, they became close friends in their youth and are both listed among the "Eight Great Prose Masters of the Tang and Song." Zeng Gong was instrumental in Ouyang Xiu's recommendation of Wang. Politically, Zeng Gong maintained a relatively neutral and reserved stance towards the reforms, but his personal friendship with Wang Anshi lasted a lifetime, remarkably surviving their political differences.

2.  **Zhou Dunyi (1017-1073)**
    *   **Relationship**: Intellectual influence.
    *   **Details**: Wang Anshi sought his advice several times. Although they did not formally establish a teacher-disciple relationship, Zhou Dunyi's Neo-Confucian philosophy influenced Wang's own philosophical views on "the principles of human nature and destiny."

### **IV. The Supreme Authority: The Emperor**

1.  **Emperor Shenzong of Song (1048-1085)**
    *   **Relationship**: **The reforms' supreme supporter and protector.**
    *   **Details**: The young and ambitious Emperor Shenzong sought to enrich the state and strengthen the military. His relationship with Wang was a classic case of "perfect understanding between ruler and minister." His unconditional trust and support were the foundation for the reforms' implementation. However, as opposition grew and results fell short of expectations, the Emperor's resolve wavered, leading to Wang's two dismissals. Shenzong's death effectively marked the end of the reform era.

### **Interpersonal Network Summary Chart**

| Person | Relationship with Wang Anshi | Stance on Reforms | Key Point |
| :--- | :--- | :--- | :--- |
| **Emperor Shenzong** | Ruler & Reform Ally | Supreme Supporter | The relationship determined the fate of the reforms. |
| **Lü Huiqing** | Aide → Political Enemy | Supporter (New Party) | The most talented but most destructive ally. |
| **Zhang Dun** | Loyal Ally | Supporter (New Party) | Staunch second-generation reform core. |
| **Wang Pang** | Son & Strategist | Supporter (New Party) | Family inner circle, source of radical strategies. |
| **Sima Guang** | Friend → Political Enemy | Opponent (Old Party Leader) | A clash of principles, fundamental ideological opposition. |
| **Su Shi/Su Zhe** | Colleagues → Political Enemies | Opponents (Old Party) | From literary friends to political rivals, reconciled later in life. |
| **Han Qi** | Senior Mentor → Opponent | Opponent (Old Party) | The opposition of a senior statesman carried immense weight. |
| **Ouyang Xiu** | Literary Mentor | Mild Opposition | Admired his talent, disagreed with his methods. |
| **Zeng Gong** | Lifelong Friend | Largely Neutral | A model of personal friendship transcending political views. |

**Summary**:
Wang Anshi's interpersonal network clearly demonstrates the principle of **"united by politics, divided by politics."** His reforms split the entire elite class into two major camps, turning many former mentors and friends into political enemies. Furthermore, his own support team was fractured by internal power struggles and clashing personalities. This complex network was both the engine that drove the reforms and a key reason for their eventual downfall into partisan strife and their abandonment after his death. His friendship with Zeng Gong stands as a warm and unique bond within this fractured web of relationships.

## Wang Anshi's relationship with Su Shi
![alt text](deepseek_mermaid_20251026_bf6e95.png)

### 1. Early Career: Respectful Rivalry (1050s-1060s)
Before the political storm, both men were rising stars in the literary and intellectual world.

Mutual Recognition of Talent: Wang Anshi was already an esteemed scholar and poet, while the younger Su Shi was a prodigy whose literary genius was widely recognized. They moved in the same elite circles and were aware of each other's formidable talents.

A Foundation of Respect: There was no deep personal animosity initially. Wang Anshi acknowledged Su Shi's literary abilities, and Su Shi respected Wang Anshi's intellectual depth and earlier literary works. Their differences at this stage were more stylistic and temperamental, not yet ideological.

### 2. The Reform Era: Political Enemies (1070s)
When Emperor Shenzong empowered Wang Anshi to launch his New Policies in 1069, their relationship shattered.

Fundamental Ideological Clash: Su Shi was a moderate reformer who believed in gradual, pragmatic change led by virtuous officials. He saw Wang Anshi's sweeping, state-controlled reforms as radical, harsh, and detrimental to the people. He became one of the most eloquent and vocal critics of the New Policies.

Direct Opposition: Su Shi submitted memorials to the throne explicitly criticizing the reforms, such as the problematic implementation of the Green Sprouts Law and the Market Exchange Law. He argued they created more burdens for the peasants and enriched the state at the people's expense.

Wang Anshi's Irritation: Su Shi's criticisms, often expressed in his brilliant and influential prose, were a significant thorn in Wang Anshi's side. Wang, a stubborn and determined man, saw Su Shi as part of the conservative obstructionism he despised.

The "Crow Terrace Poetry Case" (1079): This was the lowest point. After Wang Anshi had already retired, his successors in the New Party used lines from Su Shi's poetry to accuse him of sedition and disrespecting the emperor. Su Shi was arrested, imprisoned, and nearly executed before being exiled to Huangzhou.

Crucially, while Wang Anshi was not involved in this plot, it was orchestrated by his former allies and was a direct consequence of the toxic political atmosphere the reform debate had created.

### 3. Retirement and Reconciliation: The Jinling Meeting (1084-1085)
With both men out of power—Wang Anshi in retirement in Jinling (modern Nanjing) and Su Shi en route to a new post after his exile—their relationship underwent a profound transformation.

A Changed Wang Anshi: Away from the political fray, Wang Anshi had mellowed. He reportedly followed Su Shi's literary output during his exile and expressed admiration for his character and resilience.

Su Shi's Visit (1084): As Su Shi's boat passed through Jinling, he decided to pay a visit to the former chancellor. This was a courageous and magnanimous act, given their history.

A Meeting of Minds: For about a month, the two literary giants spent time together, discussing poetry, Buddhism, and classical scholarship. They deliberately avoided the toxic topic of politics.

Mutual Admiration: Reportedly, after their meetings, Wang Anshi sighed and told others, "It will be difficult for another genius like this to appear in three hundred years!" He deeply respected Su Shi's decision to visit him, seeing it as a mark of great character. Su Shi, in turn, was charmed by the retired statesman's intellect and found a kindred spirit in their shared love for literature and philosophy.

### 4. Final Years and Legacy: Posthumous Respect
Wang Anshi's Death (1086): When Wang Anshi died, the political tides had turned again, and the Old Party led by Sima Guang was dismantling his reforms. In this atmosphere, it would have been easy for Su Shi to join in the condemnation.

Su Shi's Defense: Instead, Su Shi demonstrated his greatness. When the government considered posthumously demoting Wang Anshi, Su Shi drafted a memorial arguing forcefully against it. He wrote that Wang Anshi should be judged for his personal integrity and his original intent to strengthen the empire, not just for the negative consequences of his policies. He praised Wang's frugality, learning, and lack of personal corruption, calling him a "extraordinary man" 

Summary of the Transformation
The relationship between Wang Anshi and Su Shi is a powerful narrative that transcends simple political factionalism. It shows:

Politics vs. Humanity: They could be absolute opponents in the political arena, yet still connect on a fundamental human level as scholars and poets.

The Mellowing Effect of Time: Age and distance from power allowed them to see past their ideological differences and appreciate each other's core virtues.

A Story of Redemption and Grace: Su Shi's visit to Jinling and his defense of Wang Anshi's character after his death are remembered as acts of immense intellectual grace and moral integrity. It elevated their story from a mere political feud to a timeless lesson in reconciliation.

## Wang Anshi's relationship between Wang Anshi and Sima Guang

![alt text](deepseek_mermaid_20251026_010b4f.png)

### 1. Early Career: Respected Friends and Colleagues (1040s-1060s)
Before the reforms, Wang Anshi and Sima Guang were not just colleagues; they were two brilliant stars of their generation, mutually respected for their intelligence, integrity, and erudition.

Service under Bao Zheng: They famously served together on the same staff under the renowned official Bao Zheng in Kaifeng. Though stories differ on their interactions, this period cemented their awareness of each other as men of exceptional ability.

Mutual Admiration: Both were seen as upright, scholarly, and uncorrupted by the political games of the court. They shared a common goal: to strengthen the Song Dynasty and address its administrative and financial woes. They moved in the same intellectual circles and were considered two of the finest minds of their time.

### 2. The Irreconcilable Split: The New Policies (1069-1085)
When Emperor Shenzong ascended the throne and empowered Wang Anshi to launch his New Policies in 1069, the deep ideological rift between the two men tore their friendship apart.

Their clash was not personal spite, but a fundamental disagreement on the role of government and the nature of Confucian governance.

Aspect	Wang Anshi's View (The Reformer)	Sima Guang's View (The Conservative)
Role of Government	Proactive & Managerial: The state should actively manage the economy, society, and commerce to increase national wealth and power.	Limited & Moralistic: The government's role is to maintain order, set a moral example, and practice frugality. It should not compete with the people for profit.
Core Philosophy	"The state should take charge of all financial resources in the empire." Believed in using state power to redistribute wealth and curb the "merciless landlords and merchants."	"The emperor should benevolently care for the people, not profit from them." Saw the New Policies as legalized plunder that created more suffering than it alleviated.
Method	Relied on laws and institutions (法, fǎ). Believed a good system could produce good outcomes.	Relied on the moral character of leaders (德, dé). Believed good men were the foundation of good government.
Key Events during the Conflict:

"The War of the Memorials": They engaged in a famous written debate through memorials to the emperor. Sima Guang sent Wang Anshi long, meticulously argued letters detailing the harms of the New Policies, urging him to abandon them. Wang Anshi responded with his famous essay, "In Reply to Sima Guang's Remonstrance," which was a forceful and unyielding defense of his reforms.

Sima Guang's Self-Exile: Seeing that he could not sway the emperor or Wang Anshi, Sima Guang made a principled stand. In 1071, he refused to serve in a government implementing these policies and requested a post outside the capital. He was sent to Luoyang, where he spent the next 15 years in scholarly opposition, focusing on his monumental history book, Zizhi Tongjian (Comprehensive Mirror in Aid of Governance).

The Nature of the Conflict: Despite their intense opposition, it remained largely a clash of principles, not a petty personal feud. They accused each other of leading the empire to ruin, but their attacks were based on policy and ideology. Sima Guang considered Wang Anshi stubborn and misguided, while Wang saw Sima as hopelessly antiquated.

### 3. Political Reversal and Final Acts (1085-1086)
The dynamic shifted dramatically with the death of Emperor Shenzong in 1085.

Sima Guang in Power: The new Emperor Zhezong was a child, and the regent, Empress Dowager Gao, was a staunch opponent of the New Policies. She summoned Sima Guang back to the capital and appointed him Chancellor.

The Dismantling of the Reforms: Sima Guang immediately launched a campaign to abolish the New Policies. He moved with great haste, arguing that the harm they caused was so severe that they had to be eliminated as quickly as possible. This period is known as the "Yuanyou Administration."

Wang Anshi's Death: Wang Anshi was living in retirement in Jiangning (modern Nanjing). He watched in despair as his life's work was systematically dismantled. He died in 1086, a year after Sima Guang returned to power, said to be heartbroken over the repeal of his reforms.

### 4. Legacy
The Wang Anshi-Sima Guang rivalry became the defining political schism of the Northern Song, creating the "Yuanyou Party Struggle," which pitted the "New Party" (reformers) against the "Old Party" (anti-reformers) for decades, severely weakening the dynasty.

A Tale of Two Legacies: For centuries, Sima Guang was celebrated in orthodox Confucian history as the wise conservative who saved the people from a misguided tyrant. Wang Anshi was vilified as an arrogant radical.

Modern Re-evaluation: In the 20th century, historians began to see Wang Anshi as a visionary proto-modernist, while Sima Guang was sometimes criticized as a reactionary who blocked necessary change.

The Ultimate Irony: Both men were brilliant, uncorrupt, and sought to save the Song Dynasty. Yet, their utterly incompatible philosophies led them to become arch-rivals, and their conflict ultimately contributed to the political factionalism that weakened the Song state, leading to its eventual collapse.

## Wang Anshi's relationship with Song Shen Emperor
![alt text](deepseek_mermaid_20251026_5c205a.png)

### 1. The Foundation: A Meeting of Minds (Before 1069)
Shenzong's Ambition: Emperor Shenzong (r. 1067-1085) was a young, energetic, and deeply frustrated ruler when he ascended the throne. He inherited an empire plagued by financial weakness, military humiliation, and bureaucratic inertia. He was determined to reverse the dynasty's fortunes and restore the legendary power and prosperity of the Han and Tang dynasties.

Wang Anshi's Reputation: Wang Anshi was already famous throughout the empire. His reputation was built on:

Profound Scholarship: He was a brilliant Confucian scholar.

Proven Administrative Skill: He had successfully implemented local reforms in various regional posts.

A Clear Vision: He had written a famous memorial to Emperor Renzong (Shenzong's predecessor) outlining his comprehensive philosophy of governance.

Personal Integrity: He was famously uncorrupt and ascetic, wholly dedicated to his principles.

Shenzong summoned Wang Anshi and asked him the pivotal question: "What must be done to govern the empire successfully?" Wang Anshi's famous reply was: "To govern successfully, the right policies must be chosen. But to choose the right policies, the right men must be found." This conversation convinced Shenzong that he had found the man with the blueprint to save the empire.

### 2. The Golden Age: Unwavering Trust and Radical Reform (1069-1074)
This was the honeymoon period of their relationship, characterized by almost absolute trust and support from the Emperor.

Appointment as Chancellor: In 1069, Shenzong appointed Wang Anshi to the powerful position of Canzhizhengshi (Participator in Determining Governmental Matters), effectively making him the chief minister.

The Launch of the New Policies: With Shenzong's full backing, Wang Anshi launched his sweeping reforms: the Green Sprouts Law, the Militia Law, the Market Exchange Law, and others.

Shenzong's "Protective Shield": The New Policies faced ferocious opposition from nearly the entire conservative establishment, including towering figures like Sima Guang, Su Shi, and Han Qi. They submitted memorials condemning Wang Anshi as a dangerous radical. Shenzong's key role was to act as Wang's protector. He consistently dismissed the criticisms, defended Wang Anshi, and removed his opponents from court. This unwavering support was the only reason the reforms could be implemented.

### 3. The Cracks Appear: Strained Relations and First Resignation (1074-1075)
No partnership could withstand such immense pressure indefinitely. Cracks began to show.

Practical Setbacks: The idealistic theories of the reforms often clashed with messy reality. Implementation by local officials was frequently corrupt or incompetent, leading to unintended suffering.

Heavenly Portents: A severe drought in 1074 was interpreted by conservatives as a sign of Heaven's displeasure with the reforms. A powerful visual protest, a "Scroll of the Refugees," was presented to the emperor, graphically depicting the suffering caused by the policies.

Shenzong's Wavering Resolve: The constant criticism and evidence of problems shook Shenzong's confidence. For the first time, he began to question Wang Anshi directly about the harms of the New Policies.

Wang Anshi's First Resignation: Feeling the erosion of the Emperor's absolute trust and grieving the death of his son, Wang Anshi resigned in 1074 and returned to Nanjing.

### 4. The Final Parting: The Second Chancellorship and Final Resignation (1075-1076)
Recall and Strained Return: Without Wang Anshi, the reform momentum stalled. Shenzong recalled him in 1075. However, their relationship was never the same. The Emperor was now more assertive and willing to modify the policies, and the political factionalism within the reform camp itself (especially from Wang's former protégé, Lü Huiqing) had intensified.

Final Resignation: In 1076, following the death of his beloved son and primary political confidant, Wang Pang, Wang Anshi was spiritually broken. He resigned for the final time and returned to Nanjing for good.

### 5. Aftermath and Legacy: A Dream Unfulfilled
Shenzong's Lonely Path: After Wang's departure, Shenzong continued to implement versions of the New Policies, but the driving ideological force was gone. The reforms became more pragmatic and less coherent.

A Tragic End: Emperor Shenzong died in 1085, his dream of a fully revitalized empire only partially realized. Upon hearing of Shenzong's death in 1086, the retired Wang Anshi was said to be utterly distraught. He died a few months later, despairing that the new regent, Empress Dowager Gao, was systematically dismantling his life's work under the guidance of his arch-rival, Sima Guang.

Summary of the Relationship
The relationship between Shenzong and Wang Anshi was a powerful but ultimately tragic partnership.

The Catalyst: Shenzong's ambition was the necessary catalyst for reform.

The Architect: Wang Anshi was the brilliant, uncompromising architect with a comprehensive plan.

The Shield: Shenzong's unwavering trust was the essential shield against opposition.

The Flaw: Both men were, to a degree, ideologues. Wang was stubborn and dismissed all criticism, while Shenzong, though initially steadfast, ultimately lacked the resilience to ignore the mounting evidence of problems.

Their story is a poignant example of how even the most perfect alignment of a ruler's will and a minister's vision can be undone by practical difficulties, political resistance, and the immense personal toll of driving radical change.

